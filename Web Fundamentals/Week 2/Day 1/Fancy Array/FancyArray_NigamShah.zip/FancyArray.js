function fancyArr(arr){
    for(var i=0; i<arr.length; i++){
        console.log(i+" -> "+arr[i]);
    }
}
fancyArr(["James", "Jill","Jane","Jack"]);
